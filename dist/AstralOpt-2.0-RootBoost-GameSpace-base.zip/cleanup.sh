if [ -f /data/adb/modules/AstralOpt/disable ]; then
  cat /data/adb/modules/AstralOpt/module.prop.orig > /data/adb/modules/AstralOpt/module.prop
  rm /data/adb/service.d/.astral_cleanup.sh
fi
