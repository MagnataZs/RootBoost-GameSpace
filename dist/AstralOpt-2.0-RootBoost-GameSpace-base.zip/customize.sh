#
# Copyright (C) 2026-2027 Zexshia
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

SKIPUNZIP=1

# Paths
MODULE_CONFIG="/data/adb/.config/AstralOpt"
HM_DIR="/data/adb/hybrid-mount"
HM_CONFIG="$HM_DIR/config.toml"

# Create File
make_node() {
	[ ! -f "$2" ] && echo "$1" >"$2"
}

abort_corrupted() {
  clear
  echo ""
  echo "! Installation Aborted"
  echo "! The package appears to be corrupted or incomplete."
  echo "! Required installation files were not found."
  echo ""
  abort "! Please re-download the module and try again."
}

abort_arch() {
  clear
  echo "! Installation Aborted"
  echo "! Unsupported CPU Architecture Detected"
  echo "! Your device architecture is not compatible with this build of AstralOpt."
  echo "! Supported architectures:"
  abort "  • arm64-v8a"
}

installation_complete() {
  echo "- AstralOpt has been successfully installed"
}

# Displaybanner
echo ""
echo "              AstralOpt              "
echo ""
echo "- Installing AstralOpt..."

# Extract Module Directiories
mkdir -p "$MODULE_CONFIG"
mkdir -p "$MODPATH/system/bin"
echo "- Create module config"

# Flashable integrity checkup
echo "- Extracting verify.sh"
unzip -o "$ZIPFILE" 'verify.sh' -d "$TMPDIR" >&2
[ ! -f "$TMPDIR/verify.sh" ] && abort_corrupted
source "$TMPDIR/verify.sh"

# Target architecture detection
case $ARCH in
"arm64") ARCH_TMP="arm64-v8a" ;;
*) abort_arch ;;
esac

echo "- Extracting binaries for $ARCH_TMP..."
extract "$ZIPFILE" AstralOpt "$MODPATH/system/bin"
echo "- All binaries installed successfully"

# Extract Module standard files
echo "- Extracting service.sh..."
extract "$ZIPFILE" service.sh "$MODPATH"
echo "- Extracting cleanup.sh..."
extract "$ZIPFILE" cleanup.sh "$MODPATH"
echo "- Extracting module.prop..."
extract "$ZIPFILE" module.prop "$MODPATH"
echo "- Extracting uninstall.sh..."
extract "$ZIPFILE" uninstall.sh "$MODPATH"
echo "- Extracting module banner..."
extract "$ZIPFILE" module.banner.jpg "$MODPATH"
echo "- Extracting App Monitor..."
extract "$ZIPFILE" AstralOpt.apk "$MODPATH"

# Skip mountify
touch "$MODPATH/skip_mountify"

# Skip hybrid mount
if [ -f "$HM_CONFIG" ]; then
    echo "- Hybrid Mount detected, configuring rules..."

    HM_BIN=""
    if [ -x "/data/adb/modules/hybrid_mount/hybrid-mount" ]; then
        HM_BIN="/data/adb/modules/hybrid_mount/hybrid-mount"
    elif command -v hybrid-mount >/dev/null 2>&1; then
        HM_BIN="hybrid-mount"
    fi

    if [ -n "$HM_BIN" ]; then
        echo "- Found Hybrid Mount CLI at: $HM_BIN"
        $HM_BIN api config-patch --patch '{"rules":{"AstralOpt":{"default_mode":"ignore"}}}' --apply-runtime >/dev/null 2>&1
        echo "- Runtime policy for AstralOpt updated to 'ignore'."
    else
        echo "- Warning: CLI binary not found in standard paths. Skipping live patch."
    fi

    if ! grep -q "\[rules\.AstralOpt\]" "$HM_CONFIG"; then
        echo "" >> "$HM_CONFIG"
        echo "[rules.AstralOpt]" >> "$HM_CONFIG"
        echo 'default_mode = "ignore"' >> "$HM_CONFIG"
        echo "- Permanent rule added to config.toml."
    fi
else
    echo "- Hybrid Mount is not installed. Skipping configuration."
fi

# Use Symlink for APatch / KernelSU
if [ "$KSU" = "true" ] || [ "$APATCH" = "true" ]; then
	# skip mount on APatch / KernelSU
	touch "$MODPATH/skip_mount"
	echo "- KSU/AP Detected, skipping module mount (skip_mount)"
	# symlink ourselves on $PATH
	manager_paths="/data/adb/ap/bin /data/adb/ksu/bin"
	BIN_PATH="/data/adb/modules/AstralOpt/system/bin"
	for dir in $manager_paths; do
		[ -d "$dir" ] && {
			echo "- Creating symlink in $dir"
			ln -sf "$BIN_PATH/AstralOpt" "$dir/AstralOpt"
		}
	done
fi

set_perm_recursive "$MODPATH/system/bin" 0 0 0755 0755

installation_complete
