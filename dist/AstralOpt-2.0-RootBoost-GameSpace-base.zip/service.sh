#!/system/bin/sh

#
# Copyright (C) 2026-2027 Zexshia
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

readonly MODDIR="${0%/*}"
readonly MODULE_CONFIG="/data/adb/.config/AstralOpt"
readonly APK_COMP="$MODDIR/AstralOpt.apk"

# Wait boot to complete
until [ "$(getprop sys.boot_completed)" = "1" ]; do 
    sleep 1
done

rm -rf "$MODULE_CONFIG/daemon.log"

# Create Cleanup Files
if [ ! -f /data/adb/service.d/.astral_cleanup.sh ]; then
  mkdir -p /data/adb/service.d
  cat "$MODDIR/cleanup.sh" > /data/adb/service.d/.astral_cleanup.sh
  chmod +x /data/adb/service.d/.astral_cleanup.sh
fi

nohup app_process -Djava.class.path="$APK_COMP" / \
    --nice-name=astral.opt-appmonitoring moe.zeshia.astralopt.MainKt \
    "$MODULE_CONFIG/gameinfo" \
    "$MODULE_CONFIG/java.lock" >"$MODULE_CONFIG/sysmon.log" 2>&1 &
    
sleep 1

exec AstralOpt