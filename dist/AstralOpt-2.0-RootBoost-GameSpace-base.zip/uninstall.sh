rm -rf /data/adb/.config/AstralOpt
manager_paths="/data/adb/ap/bin /data/adb/ksu/bin"
for dir in $manager_paths; do
	[ -d "$dir" ] && {
		for bin in AstralOpt; do
			rm "$dir/$bin"
		done
	}
done
